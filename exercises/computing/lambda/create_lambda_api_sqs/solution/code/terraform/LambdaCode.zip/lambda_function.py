import json

def lambda_handler(event, context):
    body = json.loads(event["body"])
    operand_one = body["operand_one"]
    operand_two = body["operand_two"]
    return {
        'statusCode': 200,
        'body': operand_one + operand_two
    }
