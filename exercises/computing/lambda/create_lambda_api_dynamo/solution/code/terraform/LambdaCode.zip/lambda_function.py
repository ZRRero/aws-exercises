import uuid


def get_event(id):
    pass


def save_event(event):
    id = uuid.uuid4()
    return id


def lambda_handler(event, context):
    path = event["path_parameters"]["proxy"]
    print(path)
    if path == "":
        id = save_event(event)
        return {
            "status_code": 200,
            "body": id
        }
    elif path == "":
        return {
            "status_code": 200,
            "body": "Holi"
        }
